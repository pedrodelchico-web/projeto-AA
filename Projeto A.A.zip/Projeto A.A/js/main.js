// Aplicação Principal Aprimorada
class MainApp {
    constructor() {
        this.currentSection = 'home';
        this.animationsEnabled = !this.prefersReducedMotion();
        this.init();
    }

    init() {
        this.setupNavigation();
        this.setupAnimations();
        this.setupForms();
        this.setupInteractiveElements();
        this.setupPerformance();
        this.initializeTypingEffect();
        this.initializeParticles();
        this.setupIntersectionObserver();
    }

    // Navegação Aprimorada
    setupNavigation() {
        // Scroll suave
        this.setupSmoothScroll();
        
        // Menu mobile
        this.setupMobileMenu();
        
        // Navegação por seções
        this.setupSectionNavigation();
        
        // Busca
        this.setupSearch();
    }

    setupSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    this.scrollToElement(target);
                }
            });
        });
    }

    scrollToElement(element, offset = 100) {
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - offset;

        window.scrollTo({
            top: offsetPosition,
            behavior: this.animationsEnabled ? 'smooth' : 'auto'
        });

        // Atualizar seção atual
        this.updateCurrentSection(element.id);
    }

    setupMobileMenu() {
        const toggle = document.getElementById('mobile-menu-toggle');
        const menu = document.getElementById('main-menu');

        if (toggle && menu) {
            toggle.addEventListener('click', () => {
                const isExpanded = toggle.getAttribute('aria-expanded') === 'true';
                toggle.setAttribute('aria-expanded', !isExpanded);
                menu.classList.toggle('active');
                
                // Prevenir scroll do body quando menu está aberto
                document.body.style.overflow = menu.classList.contains('active') ? 'hidden' : '';
            });

            // Fechar menu ao clicar em um link
            menu.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    toggle.setAttribute('aria-expanded', 'false');
                    menu.classList.remove('active');
                    document.body.style.overflow = '';
                });
            });

            // Fechar menu ao pressionar ESC
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && menu.classList.contains('active')) {
                    toggle.setAttribute('aria-expanded', 'false');
                    menu.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }
    }

    setupSectionNavigation() {
        // Atualizar navegação baseado na scroll position
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.updateCurrentSection(entry.target.id);
                }
            });
        }, { threshold: 0.5 });

        // Observar todas as seções principais
        document.querySelectorAll('section[id]').forEach(section => {
            observer.observe(section);
        });
    }

    updateCurrentSection(sectionId) {
        this.currentSection = sectionId;
        
        // Atualizar links ativos
        document.querySelectorAll('nav a').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${sectionId}`) {
                link.classList.add('active');
            }
        });

        // Anunciar mudança para leitores de tela
        this.announceSectionChange(sectionId);
    }

    announceSectionChange(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            const heading = section.querySelector('h1, h2, h3')?.textContent || sectionId;
            window.accessibilityManager?.announceToScreenReader(`Navegado para: ${heading}`);
        }
    }

    setupSearch() {
        const toggle = document.getElementById('search-toggle');
        const searchBox = document.getElementById('search-box');
        const searchInput = document.getElementById('search-input');

        if (toggle && searchBox) {
            toggle.addEventListener('click', () => {
                const isExpanded = toggle.getAttribute('aria-expanded') === 'true';
                toggle.setAttribute('aria-expanded', !isExpanded);
                searchBox.classList.toggle('active');
                
                if (!isExpanded && searchInput) {
                    setTimeout(() => searchInput.focus(), 100);
                }
            });

            // Buscar ao pressionar Enter
            if (searchInput) {
                searchInput.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') {
                        this.performSearch(searchInput.value);
                    }
                });
            }
        }
    }

    performSearch(query) {
        if (query.trim()) {
            // Implementar lógica de busca
            console.log('Buscando:', query);
            window.accessibilityManager?.showToast(`Buscando por: ${query}`, 'info');
        }
    }

    // Animações Aprimoradas
    setupAnimations() {
        if (!this.animationsEnabled) return;

        this.setupScrollAnimations();
        this.setupHoverEffects();
        this.setupLoadingAnimations();
    }

    setupScrollAnimations() {
        const animatedElements = document.querySelectorAll('.animate-on-scroll');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, { threshold: 0.1 });

        animatedElements.forEach(el => observer.observe(el));
    }

    setupHoverEffects() {
        // Efeitos de hover para cards interativos
        document.querySelectorAll('.service-card, .feature-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                if (this.animationsEnabled) {
                    card.style.transform = 'translateY(-5px)';
                }
            });
            
            card.addEventListener('mouseleave', () => {
                if (this.animationsEnabled) {
                    card.style.transform = 'translateY(0)';
                }
            });
        });
    }

    setupLoadingAnimations() {
        // Animar números estatísticos
        this.animateStats();
    }

    animateStats() {
        const statNumbers = document.querySelectorAll('.stat-number');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateValue(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        statNumbers.forEach(stat => observer.observe(stat));
    }

    animateValue(element) {
        const target = parseInt(element.getAttribute('data-target'));
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;

        const timer = setInterval(() => {
            current += step;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            element.textContent = Math.floor(current);
        }, 16);
    }

    // Sistema de Formulários Aprimorado
    setupForms() {
        const contactForm = document.getElementById('contact-form');
        if (contactForm) {
            this.setupFormValidation(contactForm);
            this.setupFormSubmission(contactForm);
        }
    }

    setupFormValidation(form) {
        const inputs = form.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            // Validação em tempo real
            input.addEventListener('blur', () => {
                this.validateField(input);
            });
            
            input.addEventListener('input', () => {
                this.clearFieldError(input);
            });
        });

        // Contador de caracteres para textarea
        const messageInput = form.querySelector('#message');
        if (messageInput) {
            const charCounter = form.querySelector('#char-count');
            messageInput.addEventListener('input', () => {
                const count = messageInput.value.length;
                charCounter.textContent = count;
                
                if (count > 500) {
                    charCounter.style.color = 'var(--error-color)';
                } else if (count > 400) {
                    charCounter.style.color = 'var(--warning-color)';
                } else {
                    charCounter.style.color = 'var(--text-muted)';
                }
            });
        }
    }

    validateField(field) {
        const value = field.value.trim();
        let isValid = true;
        let errorMessage = '';

        switch (field.type) {
            case 'email':
                if (!value) {
                    errorMessage = 'E-mail é obrigatório';
                    isValid = false;
                } else if (!this.isValidEmail(value)) {
                    errorMessage = 'E-mail inválido';
                    isValid = false;
                }
                break;
                
            case 'text':
                if (!value && field.required) {
                    errorMessage = 'Este campo é obrigatório';
                    isValid = false;
                }
                break;
                
            case 'select-one':
                if (!value && field.required) {
                    errorMessage = 'Por favor, selecione uma opção';
                    isValid = false;
                }
                break;
        }

        if (!isValid) {
            this.showFieldError(field, errorMessage);
        } else {
            this.clearFieldError(field);
        }

        return isValid;
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    showFieldError(field, message) {
        this.clearFieldError(field);
        
        const error = document.createElement('span');
        error.className = 'error-message';
        error.id = `${field.id}-error`;
        error.textContent = message;
        error.setAttribute('role', 'alert');
        
        field.parentNode.appendChild(error);
        field.setAttribute('aria-invalid', 'true');
        field.classList.add('error');
    }

    clearFieldError(field) {
        const existingError = field.parentNode.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        field.setAttribute('aria-invalid', 'false');
        field.classList.remove('error');
    }

    setupFormSubmission(form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            if (this.validateForm(form)) {
                await this.submitForm(form);
            }
        });
    }

    validateForm(form) {
        const inputs = form.querySelectorAll('input, select, textarea');
        let isValid = true;

        inputs.forEach(input => {
            if (!this.validateField(input)) {
                isValid = false;
            }
        });

        return isValid;
    }

    async submitForm(form) {
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        
        // Mostrar estado de carregamento
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
        submitBtn.disabled = true;

        try {
            // Simular envio (substituir por API real)
            await this.simulateApiCall();
            
            window.accessibilityManager?.showToast('Mensagem enviada com sucesso!', 'success');
            form.reset();
            
            // Resetar contador de caracteres
            const charCounter = form.querySelector('#char-count');
            if (charCounter) charCounter.textContent = '0';
            
        } catch (error) {
            window.accessibilityManager?.showToast('Erro ao enviar mensagem. Tente novamente.', 'error');
            console.error('Erro no formulário:', error);
        } finally {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    }

    simulateApiCall() {
        return new Promise((resolve) => {
            setTimeout(resolve, 2000);
        });
    }

    // Elementos Interativos
    setupInteractiveElements() {
        this.setupTabs();
        this.setupModals();
        this.setupTooltips();
    }

    setupTabs() {
        const tabButtons = document.querySelectorAll('[role="tab"]');
        
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabPanelId = button.getAttribute('aria-controls');
                this.activateTab(button, tabPanelId);
            });
            
            button.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    const tabPanelId = button.getAttribute('aria-controls');
                    this.activateTab(button, tabPanelId);
                }
            });
        });
    }

    activateTab(selectedTab, panelId) {
        // Desativar todas as abas
        document.querySelectorAll('[role="tab"]').forEach(tab => {
            tab.setAttribute('aria-selected', 'false');
            tab.classList.remove('active');
        });
        
        // Esconder todos os painéis
        document.querySelectorAll('[role="tabpanel"]').forEach(panel => {
            panel.classList.remove('active');
        });
        
        // Ativar aba selecionada
        selectedTab.setAttribute('aria-selected', 'true');
        selectedTab.classList.add('active');
        
        // Mostrar painel correspondente
        const activePanel = document.getElementById(panelId);
        if (activePanel) {
            activePanel.classList.add('active');
        }
    }

    setupModals() {
        // Fechar modal ao clicar fora
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal(e.target.id);
            }
        });

        // Fechar modal com ESC (já tratado no accessibility.js)
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            modal.setAttribute('aria-hidden', 'true');
        }
    }

    setupTooltips() {
        // Implementar tooltips acessíveis
        const elementsWithTooltip = document.querySelectorAll('[data-tooltip]');
        
        elementsWithTooltip.forEach(element => {
            const tooltipText = element.getAttribute('data-tooltip');
            const tooltip = this.createTooltip(element, tooltipText);
            
            element.addEventListener('mouseenter', () => this.showTooltip(tooltip));
            element.addEventListener('mouseleave', () => this.hideTooltip(tooltip));
            element.addEventListener('focus', () => this.showTooltip(tooltip));
            element.addEventListener('blur', () => this.hideTooltip(tooltip));
        });
    }

    createTooltip(element, text) {
        const tooltip = document.createElement('div');
        tooltip.className = 'tooltip';
        tooltip.textContent = text;
        tooltip.setAttribute('role', 'tooltip');
        
        document.body.appendChild(tooltip);
        return tooltip;
    }

    showTooltip(tooltip) {
        tooltip.style.opacity = '1';
        tooltip.style.visibility = 'visible';
    }

    hideTooltip(tooltip) {
        tooltip.style.opacity = '0';
        tooltip.style.visibility = 'hidden';
    }

    // Efeitos Visuais Avançados
    initializeTypingEffect() {
        const typingElement = document.getElementById('typing-element');
        if (!typingElement) return;

        const words = ['Todos', 'Pessoas com Deficiência', 'Inclusão', 'Acessibilidade'];
        let wordIndex = 0;
        let charIndex = 0;
        let isDeleting = false;

        const type = () => {
            const currentWord = words[wordIndex];
            
            if (isDeleting) {
                typingElement.textContent = currentWord.substring(0, charIndex - 1);
                charIndex--;
            } else {
                typingElement.textContent = currentWord.substring(0, charIndex + 1);
                charIndex++;
            }

            if (!isDeleting && charIndex === currentWord.length) {
                isDeleting = true;
                setTimeout(type, 2000);
            } else if (isDeleting && charIndex === 0) {
                isDeleting = false;
                wordIndex = (wordIndex + 1) % words.length;
                setTimeout(type, 500);
            } else {
                setTimeout(type, isDeleting ? 100 : 200);
            }
        };

        // Iniciar apenas se animações estiverem habilitadas
        if (this.animationsEnabled) {
            setTimeout(type, 1000);
        } else {
            typingElement.textContent = 'Todos';
        }
    }

    initializeParticles() {
        const container = document.getElementById('particles-container');
        if (!container || !this.animationsEnabled) return;

        const particleCount = 50;
        
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            
            // Posição e animação aleatórias
            particle.style.left = `${Math.random() * 100}%`;
            particle.style.top = `${Math.random() * 100}%`;
            particle.style.animationDelay = `${Math.random() * 20}s`;
            particle.style.animationDuration = `${20 + Math.random() * 20}s`;
            
            container.appendChild(particle);
        }
    }

    // Performance e Otimização
    setupPerformance() {
        this.setupLazyLoading();
        this.setupDebouncedEvents();
    }

    setupLazyLoading() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        imageObserver.unobserve(img);
                    }
                });
            });

            document.querySelectorAll('img[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    }

    setupDebouncedEvents() {
        // Debounce para eventos de resize e scroll
        this.debouncedScroll = this.debounce(() => {
            this.handleScroll();
        }, 100);

        this.debouncedResize = this.debounce(() => {
            this.handleResize();
        }, 250);

        window.addEventListener('scroll', this.debouncedScroll);
        window.addEventListener('resize', this.debouncedResize);
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    handleScroll() {
        // Header sticky com efeito
        const header = document.querySelector('header');
        if (window.scrollY > 100) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    }

    handleResize() {
        // Ajustar layout em diferentes tamanhos de tela
        this.checkMobileMenuState();
    }

    checkMobileMenuState() {
        const menu = document.getElementById('main-menu');
        const toggle = document.getElementById('mobile-menu-toggle');
        
        if (window.innerWidth > 768 && menu && menu.classList.contains('active')) {
            menu.classList.remove('active');
            toggle.setAttribute('aria-expanded', 'false');
            document.body.style.overflow = '';
        }
    }

    // Observer para elementos que entram na viewport
    setupIntersectionObserver() {
        const fadeObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.service-card, .feature-card').forEach(el => {
            fadeObserver.observe(el);
        });
    }

    // Utilitários
    prefersReducedMotion() {
        return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }

    // Métodos públicos
    getCurrentSection() {
        return this.currentSection;
    }

    navigateTo(sectionId) {
        const target = document.getElementById(sectionId);
        if (target) {
            this.scrollToElement(target);
        }
    }
}

// CSS para partículas (adicionar ao CSS)
const particlesCSS = `
.particle {
    position: absolute;
    width: 2px;
    height: 2px;
    background: rgba(255, 255, 255, 0.5);
    border-radius: 50%;
    animation: float 20s infinite linear;
}

@keyframes float {
    0% {
        transform: translateY(100vh) rotate(0deg);
        opacity: 0;
    }
    10% {
        opacity: 1;
    }
    90% {
        opacity: 1;
    }
    100% {
        transform: translateY(-100px) rotate(360deg);
        opacity: 0;
    }
}

.fade-in {
    animation: fadeIn 0.6s ease-out;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.tooltip {
    position: absolute;
    background: var(--text-primary);
    color: var(--bg-primary);
    padding: var(--spacing-sm) var(--spacing-md);
    border-radius: var(--border-radius-sm);
    font-size: 0.875rem;
    white-space: nowrap;
    z-index: 1000;
    opacity: 0;
    visibility: hidden;
    transition: all var(--transition-fast);
    pointer-events: none;
}
`;

// Adicionar CSS dinamicamente
const style = document.createElement('style');
style.textContent = particlesCSS;
document.head.appendChild(style);

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    window.mainApp = new MainApp();
});

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MainApp;
}