// Gerenciador de Acessibilidade Aprimorado
class AccessibilityManager {
    constructor() {
        this.speechSynthesis = window.speechSynthesis;
        this.currentUtterance = null;
        this.isReading = false;
        this.preferences = this.loadPreferences();
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.applySavedPreferences();
        this.setupKeyboardShortcuts();
        this.initializeScreenReader();
    }

    setupEventListeners() {
        // Controles da barra de acessibilidade
        this.setupToolbarEvents();
        
        // Eventos de teclado globais
        document.addEventListener('keydown', (e) => this.handleGlobalKeyboard(e));
        
        // Observar mudanças no DOM para leitores de tela
        this.setupDOMMutationObserver();
        
        // Eventos de foco para navegação por teclado
        this.setupFocusManagement();
    }

    setupToolbarEvents() {
        // Toggle da barra
        document.getElementById('toolbar-toggle').addEventListener('click', () => {
            this.toggleToolbar();
        });

        // Controles visuais
        document.getElementById('high-contrast-btn').addEventListener('click', () => {
            this.toggleHighContrast();
        });

        document.getElementById('color-blind-btn').addEventListener('click', () => {
            this.cycleColorBlindMode();
        });

        document.getElementById('dyslexia-btn').addEventListener('click', () => {
            this.toggleDyslexiaFont();
        });

        // Controles de texto
        document.getElementById('font-increase-btn').addEventListener('click', () => {
            this.increaseFontSize();
        });

        document.getElementById('font-decrease-btn').addEventListener('click', () => {
            this.decreaseFontSize();
        });

        document.getElementById('line-height-btn').addEventListener('click', () => {
            this.toggleLineHeight();
        });

        // Controles de áudio
        document.getElementById('read-aloud-btn').addEventListener('click', () => {
            this.toggleReadAloud();
        });

        document.getElementById('pause-read-btn').addEventListener('click', () => {
            this.pauseReadAloud();
        });

        document.getElementById('stop-read-btn').addEventListener('click', () => {
            this.stopReadAloud();
        });

        // Controles de navegação
        document.getElementById('highlight-links-btn').addEventListener('click', () => {
            this.toggleLinkHighlight();
        });

        document.getElementById('simplify-layout-btn').addEventListener('click', () => {
            this.toggleSimplifiedLayout();
        });
    }

    // Implementação dos métodos de acessibilidade...
    // (Mantendo a mesma estrutura do código anterior, mas com melhorias)

    toggleHighContrast() {
        document.body.classList.toggle('high-contrast');
        const isActive = document.body.classList.contains('high-contrast');
        this.updateButtonState('high-contrast-btn', isActive);
        this.savePreference('highContrast', isActive);
        this.showToast('Modo alto contraste ' + (isActive ? 'ativado' : 'desativado'));
    }

    cycleColorBlindMode() {
        const modes = ['protanopia', 'deuteranopia', 'tritanopia', 'normal'];
        const currentMode = this.preferences.colorBlindMode || 'normal';
        const currentIndex = modes.indexOf(currentMode);
        const nextIndex = (currentIndex + 1) % modes.length;
        const nextMode = modes[nextIndex];

        // Remove todas as classes de daltonismo
        document.body.classList.remove('color-blind', 'protanopia', 'deuteranopia', 'tritanopia');
        
        if (nextMode !== 'normal') {
            document.body.classList.add('color-blind', nextMode);
        }

        this.updateButtonState('color-blind-btn', nextMode !== 'normal');
        this.savePreference('colorBlindMode', nextMode);
        this.showToast('Modo daltonismo: ' + nextMode);
    }

    toggleDyslexiaFont() {
        document.body.classList.toggle('dyslexia-friendly');
        const isActive = document.body.classList.contains('dyslexia-friendly');
        this.updateButtonState('dyslexia-btn', isActive);
        this.savePreference('dyslexiaFont', isActive);
        this.showToast('Fonte para dislexia ' + (isActive ? 'ativada' : 'desativada'));
    }

    increaseFontSize() {
        const sizes = ['normal', 'large-text', 'x-large-text', 'xx-large-text', 'xxx-large-text'];
        const currentSize = this.getCurrentFontSizeClass();
        const currentIndex = sizes.indexOf(currentSize);
        
        if (currentIndex < sizes.length - 1) {
            // Remove todas as classes de tamanho
            document.body.classList.remove(...sizes);
            // Adiciona a próxima classe
            document.body.classList.add(sizes[currentIndex + 1]);
            
            this.updateFontSizeDisplay();
            this.savePreference('fontSize', sizes[currentIndex + 1]);
            this.showToast('Tamanho da fonte aumentado');
        }
    }

    decreaseFontSize() {
        const sizes = ['normal', 'large-text', 'x-large-text', 'xx-large-text', 'xxx-large-text'];
        const currentSize = this.getCurrentFontSizeClass();
        const currentIndex = sizes.indexOf(currentSize);
        
        if (currentIndex > 0) {
            document.body.classList.remove(...sizes);
            document.body.classList.add(sizes[currentIndex - 1]);
            
            this.updateFontSizeDisplay();
            this.savePreference('fontSize', sizes[currentIndex - 1]);
            this.showToast('Tamanho da fonte diminuído');
        }
    }

    getCurrentFontSizeClass() {
        const sizes = ['xxx-large-text', 'xx-large-text', 'x-large-text', 'large-text', 'normal'];
        return sizes.find(size => document.body.classList.contains(size)) || 'normal';
    }

    updateFontSizeDisplay() {
        const sizes = {
            'normal': '100%',
            'large-text': '112%',
            'x-large-text': '125%',
            'xx-large-text': '150%',
            'xxx-large-text': '200%'
        };
        
        const currentSize = this.getCurrentFontSizeClass();
        document.getElementById('font-size-display').textContent = sizes[currentSize];
    }

    toggleLineHeight() {
        document.body.classList.toggle('increased-line-height');
        const isActive = document.body.classList.contains('increased-line-height');
        this.updateButtonState('line-height-btn', isActive);
        this.savePreference('increasedLineHeight', isActive);
        this.showToast('Espaçamento de linha ' + (isActive ? 'aumentado' : 'normal'));
    }

    toggleReadAloud() {
        if (this.isReading) {
            this.pauseReadAloud();
        } else {
            this.startReadAloud();
        }
    }

    startReadAloud() {
        if (this.speechSynthesis.speaking && this.speechSynthesis.paused) {
            this.speechSynthesis.resume();
        } else {
            const content = this.getReadableContent();
            this.speakContent(content);
        }
        
        this.isReading = true;
        this.updateReadingControls();
        document.body.classList.add('reading-active');
        this.showToast('Leitura iniciada');
    }

    pauseReadAloud() {
        if (this.speechSynthesis.speaking) {
            this.speechSynthesis.pause();
            this.isReading = false;
            this.updateReadingControls();
            this.showToast('Leitura pausada');
        }
    }

    stopReadAloud() {
        this.speechSynthesis.cancel();
        this.isReading = false;
        this.updateReadingControls();
        document.body.classList.remove('reading-active');
        this.showToast('Leitura interrompida');
    }

    speakContent(text) {
        this.stopReadAloud();
        
        this.currentUtterance = new SpeechSynthesisUtterance(text);
        this.currentUtterance.lang = 'pt-BR';
        this.currentUtterance.rate = 0.8;
        this.currentUtterance.pitch = 1;
        this.currentUtterance.volume = 1;

        this.currentUtterance.onend = () => {
            this.isReading = false;
            this.updateReadingControls();
            document.body.classList.remove('reading-active');
        };

        this.currentUtterance.onerror = (event) => {
            console.error('Erro na síntese de fala:', event);
            this.showToast('Erro na leitura do conteúdo', 'error');
            this.isReading = false;
            this.updateReadingControls();
            document.body.classList.remove('reading-active');
        };

        this.speechSynthesis.speak(this.currentUtterance);
    }

    getReadableContent() {
        const mainContent = document.getElementById('main-content');
        const elements = mainContent.querySelectorAll('h1, h2, h3, h4, h5, h6, p, li, a, button');
        
        let text = '';
        elements.forEach(element => {
            if (this.isElementVisible(element)) {
                const elementText = element.textContent.trim();
                if (elementText) {
                    // Adiciona contexto baseado no tipo de elemento
                    if (element.tagName.toLowerCase().startsWith('h')) {
                        text += `Título: ${elementText}. `;
                    } else if (element.tagName === 'A') {
                        text += `Link: ${elementText}. `;
                    } else if (element.tagName === 'BUTTON') {
                        text += `Botão: ${elementText}. `;
                    } else {
                        text += `${elementText}. `;
                    }
                }
            }
        });
        
        return text;
    }

    isElementVisible(element) {
        const style = window.getComputedStyle(element);
        return style.display !== 'none' && 
               style.visibility !== 'hidden' && 
               style.opacity !== '0' &&
               element.offsetWidth > 0 &&
               element.offsetHeight > 0;
    }

    updateReadingControls() {
        const readBtn = document.getElementById('read-aloud-btn');
        const pauseBtn = document.getElementById('pause-read-btn');
        const stopBtn = document.getElementById('stop-read-btn');

        if (this.isReading) {
            readBtn.style.display = 'none';
            pauseBtn.style.display = 'flex';
            stopBtn.style.display = 'flex';
        } else {
            readBtn.style.display = 'flex';
            pauseBtn.style.display = 'none';
            stopBtn.style.display = 'none';
        }
    }

    toggleLinkHighlight() {
        document.body.classList.toggle('highlight-links');
        const isActive = document.body.classList.contains('highlight-links');
        this.updateButtonState('highlight-links-btn', isActive);
        this.savePreference('highlightLinks', isActive);
        this.showToast('Links destacados ' + (isActive ? 'ativado' : 'desativado'));
    }

    toggleSimplifiedLayout() {
        document.body.classList.toggle('simplify-layout');
        const isActive = document.body.classList.contains('simplify-layout');
        this.updateButtonState('simplify-layout-btn', isActive);
        this.savePreference('simplifyLayout', isActive);
        this.showToast('Layout simplificado ' + (isActive ? 'ativado' : 'desativado'));
    }

    toggleToolbar() {
        const toolbar = document.getElementById('accessibility-toolbar');
        const toggleBtn = document.getElementById('toolbar-toggle');
        
        toolbar.classList.toggle('collapsed');
        const isExpanded = !toolbar.classList.contains('collapsed');
        
        toggleBtn.setAttribute('aria-expanded', isExpanded);
        toggleBtn.innerHTML = isExpanded ? 
            '<i class="fas fa-chevron-up" aria-hidden="true"></i><span class="sr-only">Recolher barra de acessibilidade</span>' :
            '<i class="fas fa-chevron-down" aria-hidden="true"></i><span class="sr-only">Expandir barra de acessibilidade</span>';
    }

    updateButtonState(buttonId, isActive) {
        const button = document.getElementById(buttonId);
        button.setAttribute('aria-pressed', isActive);
        
        if (isActive) {
            button.classList.add('active');
        } else {
            button.classList.remove('active');
        }
    }

    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Alt + 1-9: Atalhos de acesso rápido
            if (e.altKey && e.key >= '1' && e.key <= '9') {
                e.preventDefault();
                this.activateQuickAccess(parseInt(e.key));
            }
            
            // Esc: Fechar modais, parar leitura
            if (e.key === 'Escape') {
                this.handleEscapeKey();
            }
            
            // Ctrl + Alt + A: Alternar barra de acessibilidade
            if (e.ctrlKey && e.altKey && e.key === 'a') {
                e.preventDefault();
                this.toggleToolbar();
            }
        });
    }

    activateQuickAccess(number) {
        const quickAccessMap = {
            1: '#main-content',
            2: '#navigation',
            3: '#home',
            4: '#about',
            5: '#services',
            6: '#contact',
            7: '#accessibility-toolbar',
            8: 'footer',
            9: 'form'
        };

        const target = quickAccessMap[number];
        if (target) {
            const element = document.querySelector(target);
            if (element) {
                element.scrollIntoView({ behavior: 'smooth' });
                element.focus();
                this.showToast(`Navegado para: ${target}`);
            }
        }
    }

    handleEscapeKey() {
        // Parar leitura
        if (this.isReading) {
            this.stopReadAloud();
        }
        
        // Fechar modais
        const openModal = document.querySelector('.modal.active');
        if (openModal) {
            this.closeModal(openModal.id);
        }
        
        // Fechar menu mobile
        const mobileMenu = document.getElementById('main-menu');
        if (mobileMenu && mobileMenu.classList.contains('active')) {
            this.closeMobileMenu();
        }
    }

    setupDOMMutationObserver() {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            this.enhanceAccessibility(node);
                        }
                    });
                }
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    enhanceAccessibility(element) {
        // Adicionar atributos ARIA dinamicamente
        if (element.tagName === 'IMG' && !element.hasAttribute('alt')) {
            element.setAttribute('alt', 'Imagem sem descrição');
            element.setAttribute('aria-hidden', 'true');
        }

        if (element.tagName === 'BUTTON' && !element.hasAttribute('aria-label')) {
            const text = element.textContent.trim();
            if (text) {
                element.setAttribute('aria-label', text);
            }
        }

        // Melhorar formulários
        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA' || element.tagName === 'SELECT') {
            const label = element.labels?.[0];
            if (label && !element.hasAttribute('aria-labelledby')) {
                const id = label.id || this.generateId('label');
                if (!label.id) label.id = id;
                element.setAttribute('aria-labelledby', id);
            }
        }
    }

    setupFocusManagement() {
        // Manter o foco dentro de modais
        document.addEventListener('focusin', (e) => {
            const modal = e.target.closest('.modal.active');
            if (modal) {
                this.trapFocus(modal, e);
            }
        });

        // Indicador de navegação por teclado
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                document.body.classList.add('keyboard-navigation');
            }
        });

        document.addEventListener('mousedown', () => {
            document.body.classList.remove('keyboard-navigation');
        });
    }

    trapFocus(modal, event) {
        const focusableElements = modal.querySelectorAll(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];

        if (event.target === lastElement && event.shiftKey === false) {
            event.preventDefault();
            firstElement.focus();
        }

        if (event.target === firstElement && event.shiftKey === true) {
            event.preventDefault();
            lastElement.focus();
        }
    }

    // Sistema de Preferências
    loadPreferences() {
        try {
            return JSON.parse(localStorage.getItem('accessibilityPreferences')) || {};
        } catch (error) {
            console.error('Erro ao carregar preferências:', error);
            return {};
        }
    }

    savePreference(key, value) {
        this.preferences[key] = value;
        try {
            localStorage.setItem('accessibilityPreferences', JSON.stringify(this.preferences));
        } catch (error) {
            console.error('Erro ao salvar preferências:', error);
        }
    }

    applySavedPreferences() {
        // Aplicar todas as preferências salvas
        Object.keys(this.preferences).forEach(key => {
            const value = this.preferences[key];
            
            switch (key) {
                case 'highContrast':
                    if (value) document.body.classList.add('high-contrast');
                    this.updateButtonState('high-contrast-btn', value);
                    break;
                    
                case 'colorBlindMode':
                    if (value !== 'normal') {
                        document.body.classList.add('color-blind', value);
                        this.updateButtonState('color-blind-btn', true);
                    }
                    break;
                    
                case 'dyslexiaFont':
                    if (value) document.body.classList.add('dyslexia-friendly');
                    this.updateButtonState('dyslexia-btn', value);
                    break;
                    
                case 'fontSize':
                    if (value !== 'normal') {
                        document.body.classList.add(value);
                    }
                    this.updateFontSizeDisplay();
                    break;
                    
                case 'increasedLineHeight':
                    if (value) document.body.classList.add('increased-line-height');
                    this.updateButtonState('line-height-btn', value);
                    break;
                    
                case 'highlightLinks':
                    if (value) document.body.classList.add('highlight-links');
                    this.updateButtonState('highlight-links-btn', value);
                    break;
                    
                case 'simplifyLayout':
                    if (value) document.body.classList.add('simplify-layout');
                    this.updateButtonState('simplify-layout-btn', value);
                    break;
            }
        });
    }

    // Sistema de Notificações
    showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'polite');

        container.appendChild(toast);

        // Remover automaticamente após 5 segundos
        setTimeout(() => {
            if (toast.parentNode) {
                toast.style.animation = 'slideInRight 0.3s ease reverse';
                setTimeout(() => toast.remove(), 300);
            }
        }, 5000);
    }

    // Utilitários
    generateId(prefix) {
        return `${prefix}-${Math.random().toString(36).substr(2, 9)}`;
    }

    initializeScreenReader() {
        // Anunciar quando a página estiver pronta para leitores de tela
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.className = 'sr-only';
        announcement.id = 'page-announcement';
        document.body.appendChild(announcement);
        
        this.announceToScreenReader('Página carregada com recursos de acessibilidade ativos');
    }

    announceToScreenReader(message) {
        const announcement = document.getElementById('page-announcement');
        if (announcement) {
            announcement.textContent = message;
        }
    }

    // Métodos públicos para uso externo
    getCurrentPreferences() {
        return { ...this.preferences };
    }

    resetPreferences() {
        this.preferences = {};
        localStorage.removeItem('accessibilityPreferences');
        document.body.className = '';
        this.updateFontSizeDisplay();
        this.showToast('Preferências redefinidas', 'info');
    }
}

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    window.accessibilityManager = new AccessibilityManager();
    
    // Esconder tela de loading
    const loadingScreen = document.querySelector('.loading-screen');
    if (loadingScreen) {
        setTimeout(() => {
            loadingScreen.classList.add('hidden');
            setTimeout(() => loadingScreen.remove(), 300);
        }, 1000);
    }
});

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AccessibilityManager;
}